import Vue from 'vue'
import VueRouter from 'vue-router'
import ImageRecognition from '../components/ImageRecognition.vue';
import VideoRecognition from '../components/VideoRecognition.vue';
import FeatureExtractor from '../components/FeatureExtractor.vue';
import Graph from '../components/Graph.vue';

Vue.use(VueRouter)

const routes = [
  {
    path: '/image-recognition',
    name: 'image-recognition',
    component: ImageRecognition
  },
  {
    path: '/video-recognition',
    name: 'video-recognition',
    component: VideoRecognition
  },
  {
    path: '/feature-extractor',
    name: 'feature-extractor',
    component: FeatureExtractor
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
