<template>
  <div>
    <h1>{{ modelStatus }}</h1>
    <VueP5 @setup="setup" @draw="draw" @keypressed="keypressed"> </VueP5>
    <button @click="addMaskImage">Mask Image</button>
    <p>{{numberOfMaskImage}}</p>
    <button @click="addUnmaskImage">Unmask Image</button>
    <p>{{numberOfUnmaskImage}}</p>
    <button @click="trainModel">Train</button>
    <button @click="startGuessing">Start Guessing</button>
  </div>
</template>

<script>
import VueP5 from "vue-p5";

export default {
  components: {
    VueP5,
  },
  data: function() {
    return {
      classifier: null,
      img: null,
      video: null,
      resultsP: null,
      version: "",
      featureExtractor: null,
      modelStatus: "",
      numberOfMaskImage: 0,
      numberOfUnmaskImage: 0,
      sketch: null,
    };
  },
  methods: {
    startGuessing() {
        this.classify();
    },
    trainModel() {
        this.classifier.train(lossValue => {
            if (lossValue) {
                console.log(lossValue);
            } else {
                console.log("Training completed");
            }
        });
    },
    addUnmaskImage() {
        this.classifier.addImage('unmask');
        this.numberOfUnmaskImage++;
    },
    addMaskImage() {
        this.classifier.addImage('mask');
        this.numberOfMaskImage++;
    },
    setup(sketch) {
        this.sketch = sketch;
        sketch.noCanvas();
        this.video = sketch.createCapture(sketch.VIDEO);
        // ml5.imageClassifier('MobileNet', this.video).then((classifier) => {
        //     this.classifyVideo(classifier, sketch);
        // });
        this.resultsP = sketch.createP('Creating model....');
        this.featureExtractor = ml5.featureExtractor('MobileNet', () => {
            this.modelStatus = "Model loaded";
        });
        const options = {
            numLabels: 2
        };
        this.classifier = this.featureExtractor.classification(this.video, options);
    },
    draw(sk) {
      
    },
    keypressed(k) {
      console.log(k.key);
    },
    classify() {
        this.classifier.classify((err, result) => {
            if (err) {
                console.log(err);
            } else {
                this.resultsP.html(result[0].label + ' ' + this.sketch.nf(result[0].confidence, 0, 2));
                this.classify();
            }
        });
    }
  },
  mounted() {
    this.version = ml5.version;
  },
};
</script>

<style></style>
