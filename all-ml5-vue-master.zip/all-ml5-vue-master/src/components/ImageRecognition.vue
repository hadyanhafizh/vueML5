<template>
  <div>
    <h1>{{ version }}</h1>
    <VueP5 @setup="setup" @draw="draw" @keypressed="keypressed"> </VueP5>
  </div>
</template>

<script>
import VueP5 from "vue-p5";

export default {
  components: {
    VueP5,
  },
  data: function() {
    return {
      classifier: null,
      img: null,
      version: "",
    };
  },
  methods: {
    setup(sketch) {
      sketch.createCanvas(400, 400);

      this.img = sketch.loadImage("img/golden.jpg");

      this.classifier = ml5
        .imageClassifier("MobileNet")
        .then((classifier) => {
          classifier.classify(this.img, (error, result) => {
            if (error) {
              console.log(error);
            } else {
              console.log(result);
              sketch.createDiv(`Label: ${result[0].label}`);
              sketch.createDiv(
                `Confidence: ${sketch.nf(result[0].confidence, 0, 2)}`
              );
            }
          });
        })
        .catch((error) => {
          console.log(error);
        });
    },
    draw(sk) {
      sk.image(this.img, 0, 0);
    },
    keypressed(k) {
      console.log(k.key);
    },
  },
  mounted() {
    this.version = ml5.version;
  },
};
</script>

<style></style>
