<template>
  <div>
    <h1>{{ version }}</h1>
    <VueP5 @setup="setup" @draw="draw" @keypressed="keypressed"> </VueP5>
  </div>
</template>

<script>
import VueP5 from "vue-p5";

export default {
  components: {
    VueP5,
  },
  data: function() {
    return {
      classifier: null,
      img: null,
      video: null,
      resultsP: null,
      version: "",
    };
  },
  methods: {
    setup(sketch) {
        sketch.noCanvas();
        this.video = sketch.createCapture(sketch.VIDEO);
        ml5.imageClassifier('MobileNet', this.video).then((classifier) => {
            this.classifyVideo(classifier, sketch);
        });
        this.resultsP = sketch.createP('Loading model and video...');
    },
    draw(sk) {
      
    },
    keypressed(k) {
      console.log(k.key);
    },
    classifyVideo(classifier, sketch) {
        classifier.classify((err, result) => {
            if (err) {
                console.log(err);
            } else {
                this.resultsP.html(result[0].label + ' ' + sketch.nf(result[0].confidence, 0, 2));
                this.classifyVideo(classifier, sketch);
            }
        });
    }
  },
  mounted() {
    this.version = ml5.version;
  },
};
</script>

<style></style>
